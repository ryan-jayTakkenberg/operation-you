# Cloudflare Pages — Build settings reference

Geen build nodig — `index.html` is de complete app.

## Setup stappen op pages.cloudflare.com

1. **Create application** → **Connect to Git**
2. Authorize Cloudflare voor GitHub (1 minuut)
3. Selecteer deze repo
4. **Set up builds and deployments**:
   - Framework preset: **None**
   - Build command: (leeg laten)
   - Build output directory: `/`
   - Root directory: (leeg laten)
5. **Save and Deploy**

Klaar. Cloudflare deployt vanaf de root van je repo.

## Custom domein (optioneel)

Standaard URL is `[project-name].pages.dev`.

Voor eigen domein (bv. `lockin.app`):
1. In Cloudflare Pages → **Custom domains** → **Set up a custom domain**
2. Volg de DNS-instructies

## Headers / redirects (optioneel later)

Als je later headers nodig hebt (bv. PWA caching), maak `_headers` file:

```
/*
  Cache-Control: public, max-age=3600
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
```

Voor nu niet nodig.
