# OPERATION YOU

> Niet die challenge van iemand anders. Die van jou.

Een persoonlijke 75-dagen self-improvement tracker als Progressive Web App. Geen generieke regels — je vertelt je verhaal, Claude leest het en bouwt 12 dagelijkse wetten die specifiek bij jouw leven passen.

**Live demo:** *(update deze URL na deploy)*

## Wat het is

- **12 persoonlijke wetten per dag** — gegenereerd door Claude op basis van je verhaal, sterktes, zwaktes en dag-75 visie
- **Spiegel** — manifest + schaduw-analyse die jou terugkaatst wat je zelf hebt verteld
- **Chat met Claude** — persoonlijke coach die je profiel kent
- **Spraak naar tekst** voor dagboek-entries (Web Speech API, gratis)
- **Whoop integratie** — handmatige invoer van recovery/slaap/strain
- **Journey** — Instagram-stijl 75-grid van je dagen met foto's en grades
- **Build (Backlog)** — issues bijhouden voor doorontwikkeling
- **PWA** — installeerbaar op iOS/Android, werkt offline
- **DOSSIER stijl** — cream papier, mono font, rode CONFIDENTIEEL stempel

## Tech stack

- Eén HTML-bestand (`index.html`) — geen build-stap nodig
- Vanilla JavaScript — geen frameworks
- `localStorage` voor data persistence
- Anthropic Claude API (Sonnet 4) — gebruiker brengt eigen API key mee
- Web Speech API voor spraak-naar-tekst
- Web Notifications API voor dagelijkse reminders

## Installatie

### Lokaal uitproberen

Niks te builden. Open `index.html` direct in je browser of serve via simpele HTTP server:

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

### Op je telefoon installeren (PWA)

1. Open de live URL in **Safari** (iOS) of **Chrome** (Android)
2. Tik op het deel-icoon
3. Kies **"Zet op beginscherm"**
4. Open de app vanaf je beginscherm — voelt en werkt als een native app

### API key configureren

Voor gebruik buiten Claude.ai:
1. Maak gratis API key op [console.anthropic.com](https://console.anthropic.com)
2. Stort minimaal $5 op je account
3. Open de app → ⚙ Instellingen → API key → plak en sla op

Verwachte kosten bij dagelijks gebruik: €2–10 per maand.

## Deploy naar Cloudflare Pages

Deze repo deployt automatisch via GitHub naar Cloudflare Pages bij elke push naar `main`.

Setup (eenmalig):
1. Maak account op [pages.cloudflare.com](https://pages.cloudflare.com) (gratis)
2. Klik **Create project → Connect to Git**
3. Selecteer deze repo
4. Build settings: **leeg laten** (geen build command, geen output directory — het is gewoon `index.html`)
5. Deploy

Klaar. Bij elke `git push` deployt Cloudflare automatisch binnen ~30 seconden.

## Project structuur

```
.
├── index.html          # De hele app — één bestand
├── README.md           # Dit bestand
├── LICENSE             # MIT
├── .gitignore          # Standaard JS/HTML ignores
├── CLOUDFLARE.md       # Deploy-instructies
└── .github/
    └── workflows/
        └── lint.yml    # Automatische JS-syntax check bij elke push
```

## Roadmap

Open issues binnen de app zelf (Build-tab) of in GitHub Issues. Hoofdrichting:

- [ ] **Casino-modus toggle** — aparte regels voor vrijdag/zaterdag nachten
- [ ] **Patroon-spotter** — automatische inzichten over je gedrag
- [ ] **Foto lightbox** — fullscreen swipe-able galerij in Journey
- [ ] **Mood/energie 1-tap rating** — gecombineerd met Whoop data
- [ ] **Training log** — quick log na elke BJJ/MMA/gym sessie
- [ ] **Defensie-countdown** — afteller voor officieren-start
- [ ] **Capacitor wrapper** — voor echte App Store distributie
- [ ] **Backend** — Supabase voor accounts, sync, en API-proxy
- [ ] **Subscription model** — via RevenueCat

## Privacy

- **Alle data blijft lokaal** op je apparaat (`localStorage`)
- **Geen tracking, geen analytics, geen accounts**
- **API key blijft in je browser** — wordt nergens anders heen gestuurd
- **Claude calls gaan direct** naar Anthropic vanaf je apparaat
- **Foto's** worden lokaal opgeslagen als base64 in localStorage (worden niet geüpload)

## Licentie

MIT — zie [LICENSE](LICENSE)

## Auteur

Persoonlijk project. Gemaakt om mezelf 75 dagen te dwingen consistent te zijn, en als portfolio-stuk richting defensie-officier ICT.

Niet gemaakt om viral te gaan. Wel om te laten zien dat AI-assisted personal tools mogelijk zijn als één persoon, één weekend, één HTML-bestand.

---

*Gebouwd met [Claude](https://claude.ai)*
